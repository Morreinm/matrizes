
package exm06;


public class Exm06 {

    public static void main(String[] args) {
       
        double v[][] = new double[15][5];
        int qtd;

        for (int i = 0; i < 15; i++) {
            for (int j = 0; j < 5; j++) {
                v[i][j] = (int) (Math.random() * 10);
            }
        }

        for (int n = 0; n < 10; n++) {
            qtd = 0;

            for (int i = 0; i < 15; i++) {
                for (int j = 0; j < 5; j++) {
                    if (n == v[i][j]) {
                        qtd++;
                    }
                }
            }

            if (qtd > 1) {
                System.out.println("o numero " + n + " se repete " + qtd + " veses");
            }
        }
    }
    
}

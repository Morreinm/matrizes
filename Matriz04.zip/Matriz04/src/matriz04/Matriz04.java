package matriz04;

import java.util.Scanner;

public class Matriz04 {

    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);
        int n = 6;
        double nt[][] = new double[n][3], med = 0;
        String nm[] = new String[n];

        System.out.println("digite o nome dos alunos");

        for (int i = 0; i < n; i++) {
            System.out.print("aluno" + (i + 1) + ":");
            nm[i] = teclado.nextLine();
        }

        System.out.println("");

        for (int i = 0; i < n; i++) {
            System.out.println(nm[i] + ":");

            for (int j = 0; j < 3; j++) {
                System.out.print("nota" + (j + 1) + ":");
                nt[i][j] = teclado.nextDouble();
            }

            System.out.println("");
        }

        for (int i = 0; i < n; i++) {
            med = 0;
            System.out.println(nm[i]);

            for (int j = 0; j < 3; j++) {
                med += nt[i][j];
            }

            med = med / 3;
            System.out.println("media:" + med);

            if (med >= 6) {
                System.out.println("situaçao: aprovado");
            } else {
                System.out.println("situaçao: reprovado");
            }
        }
    }
}

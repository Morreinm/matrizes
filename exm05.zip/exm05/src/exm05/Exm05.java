package exm05;

import java.util.Scanner;

public class Exm05 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        String l[] = new String[4];
        String p[] = new String[6];
        double v[][] = new double[4][6];

        System.out.println("nome das lojas");

        for (int i = 0; i < 4; i++) {
            System.out.print("loja" + (i + 1) + ":");
            l[i] = teclado.nextLine();
        }

        System.out.println("produttos");

        for (int i = 0; i < 6; i++) {
            System.out.print("produto" + (i + 1) + ":");
            p[i] = teclado.nextLine();
        }

        System.out.println("precos");

        for (int i = 0; i < 4; i++) {
            System.out.println(l[i]);

            for (int j = 0; j < 6; j++) {
                System.out.print(p[j] + ":R$");
                v[i][j] = teclado.nextDouble();
            }
        }

        System.out.println("precos por loja");

        for (int i = 0; i < 4; i++) {
            System.out.println();
            System.out.println(l[i]);

            for (int j = 0; j < 6; j++) {
                System.out.print(p[j] + ":R$" + v[i][j] + " ");
            }

            System.out.println();
        }

    }

}

package matriz07;

import java.util.Scanner;

public class Matriz07 {

    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);
        String nomes[] = new String[40], materias[] = new String[10], nome, d;
        double meds[][] = new double[40][10], med;
        int nalunos = 0, nmateriais = 0, atv = 1, opc, repete = 0;

        do {
            repete = 0;
            System.out.println("");
            System.out.println("escolha uma açao:");
            System.out.println("1 - cadastrar diciplina");
            System.out.println("2 - cadastrar aluno");
            System.out.println("3 - cadastrar media");
            System.out.println("4 - listar diciplinas");
            System.out.println("5 - listar alunos");
            System.out.println("6 - listar alunos e medias");
            System.out.println("0 - sair");
            System.out.println("");

            opc = teclado.nextInt();
            teclado.nextLine();
            System.out.println("");

            switch (opc) {
                case 0:
                    atv = 0;
                    break;

                case 1:
                    if (nmateriais == 10) {
                        System.out.println("limite de diciplinas atingido");
                    } else {
                        System.out.print("nova materia:");
                        d = teclado.nextLine();

                        for (int i = 0; i < nmateriais; i++) {
                            if (materias[i].equals(d)) {
                                repete++;
                            }
                        }

                        if (repete > 0) {
                            System.out.println("essa materia ja existe");
                        } else {
                            materias[nmateriais] = d;
                            nmateriais++;
                        }
                    }
                    break;

                case 2:
                    if (nalunos == 40) {
                        System.out.println("limite de alunos atingido");
                    } else {
                        System.out.print("novo aluno:");
                        nomes[nalunos] = teclado.nextLine();
                        nalunos++;
                    }
                    break;

                case 3:
                    med = 0;

                    if (nalunos == 0 || nmateriais == 0) {
                        System.out.println("nao ha alunos ou diciplinas");
                    } else {
                        System.out.println("digite o nome do aluno:");
                        nome = teclado.nextLine();

                        System.out.println("qual materia vai receber a media?");
                        d = teclado.nextLine();

                        for (int i = 0; i < nalunos; i++) {
                            if (nomes[i].equals(nome)) {
                                for (int j = 0; j < nmateriais; j++) {
                                    if (materias[j].equals(d)) {
                                        System.out.print("media:");
                                        med = teclado.nextDouble();
                                        teclado.nextLine();

                                        if (med > 10 || med < 0) {
                                            System.out.println("media invalida");
                                        } else {
                                            meds[i][j] = med;
                                        }

                                        repete++;
                                    }
                                }
                            }
                        }

                        if (repete == 0) {
                            System.out.println("aluno e/ou materia nao existe");
                        }
                    }
                    break;

                case 4:
                    if (nmateriais != 0) {
                        System.out.println("lista de materias:");

                        for (int i = 0; i < nmateriais; i++) {
                            System.out.println(materias[i]);
                        }
                    } else {
                        System.out.println("nao ha materias cadastradas");
                    }
                    break;

                case 5:
                    if (nalunos != 0) {
                        System.out.println("lista de alunos:");

                        for (int i = 0; i < nalunos; i++) {
                            System.out.println(nomes[i]);
                        }
                    } else {
                        System.out.println("nao ha alunos cadastrados");
                    }
                    break;

                case 6:
                    if (nalunos == 0 || nmateriais == 0) {
                        System.out.println("nao ha alunos ou diciplinas");
                    } else {
                        System.out.println("digite a materia que quer consultar:");
                        d = teclado.nextLine();

                        for (int i = 0; i < nmateriais; i++) {
                            if (materias[i].equals(d)) {
                                System.out.println("media dos alunos em " + d + ":");

                                for (int j = 0; j < nalunos; j++) {
                                    System.out.println(nomes[j] + ":" + meds[j][i]);
                                }

                                repete++;
                            }
                        }

                        if (repete == 0) {
                            System.out.println("aluno e/ou materia nao existe");
                        }
                    }
                    break;

                default:
                    System.out.println("opçao invalida");
            }

        } while (atv == 1);
    }
}
